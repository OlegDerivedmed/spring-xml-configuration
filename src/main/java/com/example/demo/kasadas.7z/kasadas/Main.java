package com.example.demo.kasadas;


public class Main {
    public static void main(String[] args) {
        var field = new FieldFiller(new Field()).getFilledField();
        field.getShips().forEach(System.out::println);
    }
}
