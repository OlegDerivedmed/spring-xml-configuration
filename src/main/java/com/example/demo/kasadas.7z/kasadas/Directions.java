package com.example.demo.kasadas;

public enum Directions {

    LEFT,RIGHT,UP,DOWN
}
